import React from "react";

const Card = () => {
  return (
    <div
      className="bg-slate-100	opacity-80 rounded-lg   h-[10rem] w-[20rem] p-5 "
      data-aos="fade-left"
      data-aos-duration="400"
      data-aos-once="true"
    >
      <div className="flex flex-col gap-1 px-5">
        <div className="mx-auto">
          <label className="text-xl">Heading</label>
        </div>
        <div className="flex gap-1">
          <div className="rounded-md outline-none">
            <select name="cars" id="cars">
              <option value="volvo">+91</option>
              <option value="saab">+92</option>
              <option value="mercedes">+93</option>
              <option value="audi">+94</option>
            </select>
          </div>
          <div>
            <input type="text" className="rounded-md outline-none" />
          </div>
        </div>
        <div className="mt-2">
          <button
            type="button"
            className="bg-[#99CA3A] text-white p-1 px-24 rounded-md	 "
          >
            Submit
          </button>
        </div>
        <div>
          <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike" />
          <label htmlFor="vehicle1"> Remember me</label>
        </div>
      </div>
    </div>
  );
};

export default Card;
