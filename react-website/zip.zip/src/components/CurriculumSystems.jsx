import React from "react";
import WrittingImg from "../assets/curriculum-system/writting.png";
import ReadingImg from "../assets/curriculum-system/reading.png";
import PhonicsImg from "../assets/curriculum-system/phonics.png";

const CurriculumSystems = () => {
  return (
    <section
      data-aos="fade-up"
      data-aos-offset="200"
      className="container mx-auto py-8"
    >
      <div className="flex justify-center mb-8 py-2">
        <h1 className="text-3xl font-bold">量身定制的</h1>
        <h1 className="text-3xl font-bold text-[#99CA3A]">「四大課程體系」</h1>
      </div>
      <div className="flex flex-col gap-8">
        <div className="flex">
          <div className="flex flex-col gap-2 z-10">
            <h1 className="text-3xl font-bold">01</h1>
            <h1 className="text-3xl font-bold text-[#FF587C]">
              精英寫作課程 STRUCTURED WRITING
            </h1>
            <h2 className="text-2xl font-bold">拓展思維 能說會道</h2>
            <p>適合7-12歲</p>
            <div className="flex">
              <button className="rounded-lg text-white bg-[#FF587C] px-4 py-2">
                立即免費試堂
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-1 rounded-full border bg-[#F6F7FB] relative -left-[31%] w-3/6">
            <img
              className="absolute -right-[5%] top-[12%]"
              src={WrittingImg}
              alt="writting-img"
            />
          </div>
        </div>
        <div className="flex justify-end">
          <div className="flex flex-col gap-2 z-10">
            <h1 className="text-3xl font-bold">02</h1>
            <h1 className="text-3xl font-bold text-[#8DC63F]">
              閱讀課程 GUIDED READING
            </h1>
            <h2 className="text-2xl font-bold">聽說讀寫 融會貫通</h2>
            <p>適合5-12歲</p>
            <div className="flex">
              <button className="rounded-lg text-white bg-[#8DC63F] px-4 py-2">
                立即免費試堂
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-1 rounded-full border bg-[#F6F7FB] relative -left-[22%] w-3/6">
            <img
              className="absolute -right-[5%] top-[12%]"
              src={ReadingImg}
              alt="reading-img"
            />
          </div>
        </div>
        <div className="flex">
          <div className="flex flex-col gap-2 z-10">
            <h1 className="text-3xl font-bold">03</h1>
            <h1 className="text-3xl font-bold text-[#05B9F6]">
              自然拼讀課程 SUPER PHONICS CURRICULUM
            </h1>
            <h2 className="text-2xl font-bold">聽音能寫 見字能讀</h2>
            <p>適合4-7歲</p>
            <div className="flex">
              <button className="rounded-lg text-white bg-[#05B9F6] px-4 py-2">
                立即免費試堂
              </button>
            </div>
          </div>
          <div className="flex flex-col gap-1 rounded-full border bg-[#F6F7FB] relative -left-[37%] w-3/6">
            <img
              className="absolute -right-[5%] top-[12%]"
              src={PhonicsImg}
              alt="phonics-img"
            />
          </div>
        </div>
      </div>
    </section>
  );
};

export default CurriculumSystems;
